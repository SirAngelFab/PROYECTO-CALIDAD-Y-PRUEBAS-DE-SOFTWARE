# PeruShop

Frontend completo de una tienda de moda construido con Next.js, TypeScript, Tailwind CSS y Lucide React. Todos los productos son datos locales; el carrito y los favoritos persisten en `localStorage`.

## Iniciar localmente

Requisitos: Node.js 20.9 o superior y npm.

```bash
npm install
npm run dev
```

Abre [http://localhost:3000](http://localhost:3000).

## Verificaciones

```bash
npm run lint
npx tsc --noEmit
npm run build
```

## Rutas

- `/` — inicio
- `/productos` — catálogo, búsqueda, filtros y ordenamiento
- `/productos/[slug]` — detalle de producto
- `/carrito` — carrito persistente
- `/favoritos` — productos guardados
- `/checkout` — checkout visual con confirmación simulada
- `/login` y `/registro` — pantallas de acceso demostrativas

No hay autenticación, pagos, API, base de datos ni backend real.
