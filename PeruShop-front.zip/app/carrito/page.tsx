"use client";

import { CartItem } from "@/components/cart/CartItem";
import { CartSummary } from "@/components/cart/CartSummary";
import { getProductById } from "@/data/products";
import { useStore } from "@/hooks/use-store";
import { ShoppingBag } from "lucide-react";
import Link from "next/link";

export default function CartPage() {
  const { cart } = useStore();
  const lines = cart.flatMap((line) => {
    const product = getProductById(line.productId);
    return product ? [{ line, product }] : [];
  });
  const subtotal = lines.reduce((total, { line, product }) => total + product.price * line.quantity, 0);

  return (
    <div className="section-shell py-12 sm:py-16">
      <div className="mb-10"><p className="text-[10px] font-semibold uppercase tracking-[.2em] text-[#79543b]">Tu selección</p><h1 className="mt-2 font-serif text-5xl">Carrito</h1></div>
      {lines.length ? (
        <div className="grid gap-10 lg:grid-cols-[1fr_380px] lg:gap-16">
          <div><div className="flex justify-between border-b border-neutral-300 pb-4 text-xs uppercase tracking-[.12em]"><span>{lines.length} {lines.length === 1 ? "producto" : "productos"}</span><Link href="/productos" className="underline">Seguir comprando</Link></div>{lines.map(({ line, product }) => <CartItem key={line.key} line={line} product={product} />)}</div>
          <div className="lg:sticky lg:top-32 lg:self-start"><CartSummary subtotal={subtotal} /></div>
        </div>
      ) : (
        <div className="flex min-h-[420px] flex-col items-center justify-center bg-neutral-50 px-5 text-center"><ShoppingBag size={44} strokeWidth={1} /><h2 className="mt-6 font-serif text-3xl">Tu carrito está vacío</h2><p className="mt-3 max-w-sm text-sm leading-6 text-neutral-500">Descubre la colección y encuentra esa pieza que estabas buscando.</p><Link href="/productos" className="mt-7 bg-black px-7 py-4 text-xs font-semibold uppercase tracking-[.14em] text-white">Ver colección</Link></div>
      )}
    </div>
  );
}
