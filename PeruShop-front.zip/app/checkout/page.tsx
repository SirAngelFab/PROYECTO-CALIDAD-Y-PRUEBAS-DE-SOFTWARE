"use client";

import { CartSummary } from "@/components/cart/CartSummary";
import { Modal } from "@/components/ui/Modal";
import { getProductById, formatPrice } from "@/data/products";
import { useStore } from "@/hooks/use-store";
import { CheckCircle2, CreditCard, Landmark, Smartphone } from "lucide-react";
import Link from "next/link";
import { useMemo, useState, type FormEvent } from "react";

type FormErrors = Record<string, string>;

export default function CheckoutPage() {
  const { cart, clearCart } = useStore();
  const [payment, setPayment] = useState("tarjeta");
  const [errors, setErrors] = useState<FormErrors>({});
  const [confirmed, setConfirmed] = useState(false);
  const lines = useMemo(() => cart.flatMap((line) => {
    const product = getProductById(line.productId);
    return product ? [{ line, product }] : [];
  }), [cart]);
  const subtotal = lines.reduce((total, { line, product }) => total + product.price * line.quantity, 0);

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const required = ["nombre", "apellido", "email", "telefono", "direccion", "distrito", "provincia", "departamento"];
    const nextErrors: FormErrors = {};
    required.forEach((name) => { if (!String(data.get(name) ?? "").trim()) nextErrors[name] = "Este campo es obligatorio"; });
    if (data.get("email") && !/^\S+@\S+\.\S+$/.test(String(data.get("email")))) nextErrors.email = "Ingresa un correo válido";
    if (data.get("telefono") && !/^\d{9}$/.test(String(data.get("telefono")).replace(/\s/g, ""))) nextErrors.telefono = "Ingresa 9 dígitos";
    setErrors(nextErrors);
    if (!Object.keys(nextErrors).length && lines.length) {
      setConfirmed(true);
      clearCart();
    }
  };

  if (!lines.length && !confirmed) return (
    <div className="section-shell flex min-h-[60vh] flex-col items-center justify-center text-center"><h1 className="font-serif text-4xl">No hay productos para finalizar</h1><p className="mt-3 text-sm text-neutral-500">Agrega productos a tu carrito antes de continuar.</p><Link href="/productos" className="mt-7 bg-black px-7 py-4 text-xs font-semibold uppercase tracking-[.14em] text-white">Ver productos</Link></div>
  );

  return (
    <div className="section-shell py-12 sm:py-16">
      <div className="mb-10"><p className="text-[10px] font-semibold uppercase tracking-[.2em] text-[#79543b]">Último paso</p><h1 className="mt-2 font-serif text-5xl">Finalizar compra</h1><p className="mt-3 text-sm text-neutral-500">Esta es una demostración visual. No se procesará ningún pago.</p></div>
      <form onSubmit={submit} noValidate className="grid gap-10 lg:grid-cols-[1fr_400px] lg:gap-16">
        <div className="space-y-12">
          <CheckoutSection number="01" title="Datos personales">
            <div className="grid gap-5 sm:grid-cols-2"><Field name="nombre" label="Nombre" error={errors.nombre} /><Field name="apellido" label="Apellido" error={errors.apellido} /><Field name="email" type="email" label="Correo electrónico" error={errors.email} /><Field name="telefono" inputMode="numeric" label="Teléfono" placeholder="999 999 999" error={errors.telefono} /></div>
          </CheckoutSection>
          <CheckoutSection number="02" title="Dirección de entrega">
            <div className="grid gap-5 sm:grid-cols-2"><Field name="direccion" label="Dirección" className="sm:col-span-2" placeholder="Av., calle, número" error={errors.direccion} /><Field name="referencia" label="Referencia (opcional)" className="sm:col-span-2" /><Field name="distrito" label="Distrito" error={errors.distrito} /><Field name="provincia" label="Provincia" error={errors.provincia} /><Field name="departamento" label="Departamento" error={errors.departamento} /><Field name="codigo" label="Código postal (opcional)" /></div>
          </CheckoutSection>
          <CheckoutSection number="03" title="Método de pago">
            <div className="grid gap-3 sm:grid-cols-3">{[
              { id: "tarjeta", label: "Tarjeta", icon: CreditCard }, { id: "yape", label: "Yape / Plin", icon: Smartphone }, { id: "transferencia", label: "Transferencia", icon: Landmark },
            ].map(({ id, label, icon: Icon }) => <button type="button" key={id} onClick={() => setPayment(id)} className={`flex min-h-24 flex-col items-center justify-center gap-2 border p-3 text-xs transition ${payment === id ? "border-black bg-neutral-950 text-white" : "border-neutral-300 hover:border-black"}`}><Icon size={22} strokeWidth={1.4} />{label}</button>)}</div>
            <div className="mt-4 bg-neutral-50 p-4 text-xs leading-5 text-neutral-500">{payment === "tarjeta" ? "La integración segura de tarjeta se conectará cuando exista un backend." : payment === "yape" ? "El código QR se mostrará al conectar una pasarela de pago." : "Los datos bancarios se habilitarán en la versión con backend."}</div>
          </CheckoutSection>
        </div>
        <aside className="lg:sticky lg:top-32 lg:self-start">
          <div className="mb-4 max-h-56 overflow-y-auto border border-neutral-200 px-5">{lines.map(({ line, product }) => <div key={line.key} className="flex items-center justify-between gap-3 border-b border-neutral-100 py-4 last:border-0"><div className="min-w-0"><p className="truncate text-xs font-medium">{product.name}</p><p className="mt-1 text-[10px] text-neutral-500">{line.size} · {line.color} · Cant. {line.quantity}</p></div><span className="shrink-0 text-xs">{formatPrice(product.price * line.quantity)}</span></div>)}</div>
          <CartSummary subtotal={subtotal} checkout />
          <button type="submit" className="mt-4 h-13 w-full bg-black px-5 py-4 text-xs font-semibold uppercase tracking-[.15em] text-white transition hover:bg-[#79543b]">Confirmar pedido</button>
          <p className="mt-3 text-center text-[10px] leading-4 text-neutral-500">Al confirmar aceptas los términos de la experiencia demostrativa.</p>
        </aside>
      </form>
      <Modal open={confirmed} onClose={() => setConfirmed(false)} title="¡Pedido confirmado!">
        <div className="text-center"><CheckCircle2 size={54} strokeWidth={1.2} className="mx-auto text-[#587b54]" /><p className="mt-5 text-sm leading-6 text-neutral-600">Tu pedido de demostración <strong className="text-black">PS-10482</strong> fue registrado correctamente. No se ha realizado ningún cobro.</p><Link href="/" className="mt-7 inline-flex bg-black px-7 py-4 text-xs font-semibold uppercase tracking-[.14em] text-white">Volver al inicio</Link></div>
      </Modal>
    </div>
  );
}

function CheckoutSection({ number, title, children }: { number: string; title: string; children: React.ReactNode }) {
  return <section><div className="mb-6 flex items-center gap-4 border-b border-neutral-200 pb-4"><span className="text-xs text-[#79543b]">{number}</span><h2 className="font-serif text-3xl">{title}</h2></div>{children}</section>;
}

function Field({ label, error, className = "", ...props }: React.InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string }) {
  return <label className={`block ${className}`}><span className="mb-2 block text-[11px] font-medium uppercase tracking-[.12em] text-neutral-600">{label}</span><input className={`h-12 w-full border bg-white px-4 text-sm outline-none transition focus:border-black ${error ? "border-red-500" : "border-neutral-300"}`} {...props} />{error && <span className="mt-1 block text-xs text-red-600">{error}</span>}</label>;
}
