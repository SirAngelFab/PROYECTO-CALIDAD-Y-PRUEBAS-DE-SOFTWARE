"use client";

import { ProductGrid } from "@/components/ProductGrid";
import { products } from "@/data/products";
import { useStore } from "@/hooks/use-store";
import { Heart } from "lucide-react";
import Link from "next/link";

export default function FavoritesPage() {
  const { favorites } = useStore();
  const saved = products.filter((product) => favorites.includes(product.id));
  return (
    <div className="section-shell py-12 sm:py-16">
      <div className="mb-10"><p className="text-[10px] font-semibold uppercase tracking-[.2em] text-[#79543b]">Guardados para ti</p><h1 className="mt-2 font-serif text-5xl">Favoritos</h1><p className="mt-3 text-sm text-neutral-500">{saved.length} {saved.length === 1 ? "producto guardado" : "productos guardados"}</p></div>
      {saved.length ? <ProductGrid products={saved} /> : <div className="flex min-h-[420px] flex-col items-center justify-center bg-neutral-50 px-5 text-center"><Heart size={44} strokeWidth={1} /><h2 className="mt-6 font-serif text-3xl">Aún no tienes favoritos</h2><p className="mt-3 max-w-sm text-sm leading-6 text-neutral-500">Guarda tus prendas preferidas con el corazón y encuéntralas aquí cuando quieras.</p><Link href="/productos" className="mt-7 bg-black px-7 py-4 text-xs font-semibold uppercase tracking-[.14em] text-white">Descubrir productos</Link></div>}
    </div>
  );
}
