import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StoreProvider } from "@/lib/store-context";

export const metadata: Metadata = {
  title: { default: "PeruShop | Moda contemporánea", template: "%s | PeruShop" },
  description: "Moda contemporánea para mujer, hombre y accesorios. Descubre la nueva colección PeruShop.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="es">
      <body>
        <StoreProvider>
          <Header />
          <main className="min-h-[60vh]">{children}</main>
          <Footer />
        </StoreProvider>
      </body>
    </html>
  );
}
