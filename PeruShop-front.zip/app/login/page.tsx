"use client";

import { AuthShell } from "@/components/AuthShell";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { useStore } from "@/hooks/use-store";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

export default function LoginPage() {
  const [error, setError] = useState("");
  const { notify } = useStore();
  const router = useRouter();
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const email = String(data.get("email") ?? "");
    const password = String(data.get("password") ?? "");
    if (!/^\S+@\S+\.\S+$/.test(email) || password.length < 6) { setError("Revisa el correo y usa una contraseña de al menos 6 caracteres."); return; }
    setError(""); notify("Sesión simulada iniciada"); router.push("/");
  };
  return <AuthShell title="Bienvenido de nuevo" intro="Inicia sesión para ver tus favoritos y continuar donde lo dejaste." footer={<>¿Aún no tienes cuenta? <Link href="/registro" className="font-semibold text-black underline">Crear cuenta</Link></>}><form onSubmit={submit} className="space-y-5"><Input name="email" type="email" label="Correo electrónico" placeholder="tu@correo.com" required /><Input name="password" type="password" label="Contraseña" placeholder="Mínimo 6 caracteres" required minLength={6} />{error && <p className="text-xs leading-5 text-red-600">{error}</p>}<div className="flex items-center justify-between text-xs"><label className="flex items-center gap-2"><input type="checkbox" className="accent-black" /> Recordarme</label><button type="button" className="underline">Olvidé mi contraseña</button></div><Button type="submit" fullWidth>Iniciar sesión</Button><p className="text-center text-[11px] text-neutral-400">Demostración visual: no se guardan credenciales.</p></form></AuthShell>;
}
