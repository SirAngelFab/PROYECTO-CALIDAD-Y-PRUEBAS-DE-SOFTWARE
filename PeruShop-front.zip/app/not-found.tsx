import Link from "next/link";

export default function NotFound() {
  return <div className="section-shell flex min-h-[60vh] flex-col items-center justify-center text-center"><p className="text-xs font-semibold uppercase tracking-[.22em] text-[#79543b]">Error 404</p><h1 className="mt-4 font-serif text-5xl">Esta página no está disponible</h1><p className="mt-4 text-sm text-neutral-500">Quizá el producto cambió de lugar o ya no forma parte de la colección.</p><Link href="/productos" className="mt-8 bg-black px-7 py-4 text-xs font-semibold uppercase tracking-[.15em] text-white">Volver a la tienda</Link></div>;
}
