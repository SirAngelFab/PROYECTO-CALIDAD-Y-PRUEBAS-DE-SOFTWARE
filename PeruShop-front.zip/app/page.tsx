import { CategoryCard } from "@/components/CategoryCard";
import { HeroBanner } from "@/components/HeroBanner";
import { ProductGrid } from "@/components/ProductGrid";
import { products } from "@/data/products";
import { ArrowRight, RotateCcw, ShieldCheck, Truck } from "lucide-react";
import Link from "next/link";

export default function HomePage() {
  return (
    <>
      <HeroBanner />

      <section className="section-shell py-20 sm:py-28">
        <div className="mb-10 flex items-end justify-between">
          <div><p className="text-[10px] font-semibold uppercase tracking-[0.23em] text-[#79543b]">Encuentra tu estilo</p><h2 className="mt-3 font-serif text-4xl sm:text-5xl">Compra por categoría</h2></div>
          <Link href="/productos" className="hidden items-center gap-2 border-b border-black pb-1 text-xs font-semibold uppercase tracking-[0.12em] sm:flex">Ver todo <ArrowRight size={15} /></Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-3 sm:gap-5">
          <CategoryCard title="Mujer" subtitle="Siluetas esenciales" href="/productos?categoria=Mujer" product={products[16]} />
          <CategoryCard title="Hombre" subtitle="Nuevos clásicos" href="/productos?categoria=Hombre" product={products[3]} />
          <CategoryCard title="Accesorios" subtitle="El detalle final" href="/productos?categoria=Accesorios" product={products[19]} />
        </div>
      </section>

      <section className="bg-[#f5f2ed] py-20 sm:py-24">
        <div className="section-shell">
          <div className="mb-10 text-center"><p className="text-[10px] font-semibold uppercase tracking-[0.23em] text-[#79543b]">Selección PeruShop</p><h2 className="mt-3 font-serif text-4xl sm:text-5xl">Destacados de la semana</h2></div>
          <ProductGrid products={[products[0], products[2], products[6], products[8]]} compact />
          <div className="mt-12 text-center"><Link href="/productos" className="inline-flex min-h-12 items-center gap-3 border border-neutral-950 px-7 text-xs font-semibold uppercase tracking-[0.14em] transition hover:bg-black hover:text-white">Explorar colección <ArrowRight size={16} /></Link></div>
        </div>
      </section>

      <section className="grid min-h-[650px] lg:grid-cols-2">
        <div className="min-h-[520px] bg-[url('/images/hero-fashion.png')] bg-cover bg-[70%_center] lg:min-h-full" />
        <div className="flex items-center bg-[#7b5b43] px-7 py-20 text-white sm:px-16 lg:px-20">
          <div className="max-w-xl">
            <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-white/70">Nueva colección</p>
            <h2 className="mt-5 font-serif text-5xl leading-[1.02] sm:text-6xl">Texturas que cuentan nuestra historia.</h2>
            <p className="mt-7 max-w-lg text-sm leading-7 text-white/80">Una edición pensada desde Lima: tejidos suaves, paletas cálidas y cortes que acompañan el movimiento.</p>
            <Link href="/productos?orden=novedades" className="mt-9 inline-flex items-center gap-3 border-b border-white pb-2 text-xs font-semibold uppercase tracking-[0.15em]">Descubrir novedades <ArrowRight size={17} /></Link>
          </div>
        </div>
      </section>

      <section className="section-shell py-20 sm:py-28">
        <div className="mb-10 flex items-end justify-between"><div><p className="text-[10px] font-semibold uppercase tracking-[0.23em] text-[#9a3d2d]">Hasta 30% menos</p><h2 className="mt-3 font-serif text-4xl sm:text-5xl">Últimas oportunidades</h2></div><Link href="/productos?ofertas=true" className="hidden items-center gap-2 text-xs font-semibold uppercase tracking-[0.12em] sm:flex">Ver ofertas <ArrowRight size={15} /></Link></div>
        <ProductGrid products={products.filter((product) => product.tags.includes("Oferta"))} compact />
      </section>

      <section className="border-y border-neutral-200">
        <div className="section-shell grid divide-y divide-neutral-200 py-4 sm:grid-cols-3 sm:divide-x sm:divide-y-0">
          {[{ icon: Truck, title: "Envío a todo el Perú", text: "Entrega segura a tu puerta" }, { icon: RotateCcw, title: "Cambios sencillos", text: "Hasta 15 días para cambiar" }, { icon: ShieldCheck, title: "Compra protegida", text: "Experiencia segura y transparente" }].map(({ icon: Icon, title, text }) => (
            <div key={title} className="flex items-center gap-4 px-5 py-7 sm:justify-center"><Icon strokeWidth={1.4} /><div><p className="text-sm font-medium">{title}</p><p className="mt-1 text-xs text-neutral-500">{text}</p></div></div>
          ))}
        </div>
      </section>
    </>
  );
}
