import { LoadingSkeleton } from "@/components/ui/LoadingSkeleton";

export default function ProductsLoading() {
  return <div className="section-shell py-20"><LoadingSkeleton cards={8} /></div>;
}
