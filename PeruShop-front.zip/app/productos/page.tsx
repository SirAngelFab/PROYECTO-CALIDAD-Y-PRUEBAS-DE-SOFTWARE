import { ProductCatalog } from "@/components/catalog/ProductCatalog";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Productos" };

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function ProductsPage({ searchParams }: { searchParams: SearchParams }) {
  const params = await searchParams;
  const value = (key: string) => Array.isArray(params[key]) ? params[key]?.[0] : params[key];
  const initialQuery = value("q") ?? "";
  const initialCategory = value("categoria");
  const initialSort = value("orden") ?? "novedades";
  const initialOffers = value("ofertas") === "true";
  const catalogKey = `${initialQuery}-${initialCategory}-${initialSort}-${initialOffers}`;
  return <ProductCatalog key={catalogKey} initialQuery={initialQuery} initialCategory={initialCategory} initialSort={initialSort} initialOffers={initialOffers} />;
}
