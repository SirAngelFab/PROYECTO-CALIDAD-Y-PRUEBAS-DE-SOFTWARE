"use client";

import { AuthShell } from "@/components/AuthShell";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { useStore } from "@/hooks/use-store";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

export default function RegisterPage() {
  const [error, setError] = useState("");
  const { notify } = useStore();
  const router = useRouter();
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const email = String(data.get("email") ?? "");
    const password = String(data.get("password") ?? "");
    if (!String(data.get("nombre") ?? "").trim() || !/^\S+@\S+\.\S+$/.test(email) || password.length < 6) { setError("Completa los campos y usa una contraseña de al menos 6 caracteres."); return; }
    setError(""); notify("Cuenta de demostración creada"); router.push("/");
  };
  return <AuthShell title="Crea tu cuenta" intro="Guarda tus piezas favoritas y disfruta una experiencia más personal." footer={<>¿Ya tienes cuenta? <Link href="/login" className="font-semibold text-black underline">Iniciar sesión</Link></>}><form onSubmit={submit} className="space-y-5"><Input name="nombre" label="Nombre completo" required /><Input name="email" type="email" label="Correo electrónico" placeholder="tu@correo.com" required /><Input name="password" type="password" label="Contraseña" placeholder="Mínimo 6 caracteres" required minLength={6} />{error && <p className="text-xs leading-5 text-red-600">{error}</p>}<label className="flex items-start gap-2 text-xs leading-5 text-neutral-600"><input type="checkbox" required className="mt-1 accent-black" />Acepto los términos, la política de privacidad y recibir novedades de PeruShop.</label><Button type="submit" fullWidth>Crear cuenta</Button><p className="text-center text-[11px] text-neutral-400">Demostración visual: no se almacenarán tus datos.</p></form></AuthShell>;
}
