import Link from "next/link";

export function AuthShell({ title, intro, footer, children }: { title: string; intro: string; footer: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="grid min-h-[720px] lg:grid-cols-2">
      <div className="relative hidden overflow-hidden bg-[url('/images/hero-fashion.png')] bg-cover bg-center lg:block"><div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent" /><div className="absolute bottom-12 left-12 max-w-md text-white"><p className="text-[10px] uppercase tracking-[.24em] text-white/70">PeruShop Members</p><p className="mt-3 font-serif text-4xl leading-tight">Tu estilo, tus favoritos, todo en un solo lugar.</p></div></div>
      <div className="flex items-center justify-center px-5 py-16 sm:px-10"><div className="w-full max-w-md"><Link href="/" className="text-sm font-semibold tracking-[.25em]">PERUSHOP</Link><h1 className="mt-10 font-serif text-5xl">{title}</h1><p className="mt-4 text-sm leading-6 text-neutral-500">{intro}</p><div className="mt-8">{children}</div><div className="mt-8 border-t border-neutral-200 pt-6 text-center text-sm text-neutral-600">{footer}</div></div></div>
    </div>
  );
}
