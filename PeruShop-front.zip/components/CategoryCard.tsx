import type { Product } from "@/types";
import { ArrowUpRight } from "lucide-react";
import Link from "next/link";
import { ProductImage } from "./ProductImage";

export function CategoryCard({ title, subtitle, href, product }: { title: string; subtitle: string; href: string; product: Product }) {
  return (
    <Link href={href} className="group relative block aspect-[4/5] overflow-hidden bg-[#eee9e1]">
      <ProductImage product={product} className="absolute inset-0 transition-transform duration-700 ease-out group-hover:scale-[1.035]" />
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/65 to-transparent p-5 pt-24 text-white sm:p-7">
        <p className="text-[10px] uppercase tracking-[0.2em] text-white/75">{subtitle}</p>
        <div className="mt-2 flex items-end justify-between">
          <h3 className="font-serif text-3xl sm:text-4xl">{title}</h3>
          <span className="flex size-10 items-center justify-center rounded-full border border-white/50 transition group-hover:bg-white group-hover:text-black"><ArrowUpRight size={19} /></span>
        </div>
      </div>
    </Link>
  );
}
