"use client";

import { RotateCcw, X } from "lucide-react";

export interface Filters {
  categories: string[];
  sizes: string[];
  colors: string[];
  maxPrice: number;
  offersOnly: boolean;
}

interface FilterSidebarProps {
  filters: Filters;
  onChange: (filters: Filters) => void;
  mobile?: boolean;
  onClose?: () => void;
}

const categories = ["Mujer", "Hombre", "Accesorios"];
const sizes = ["XS", "S", "M", "L", "XL", "Única"];
const colors = ["Negro", "Blanco", "Camel", "Cacao", "Borgoña", "Olivo", "Azul noche"];

export const initialFilters: Filters = { categories: [], sizes: [], colors: [], maxPrice: 500, offersOnly: false };

export function FilterSidebar({ filters, onChange, mobile, onClose }: FilterSidebarProps) {
  const toggle = (key: "categories" | "sizes" | "colors", value: string) => {
    const values = filters[key];
    onChange({ ...filters, [key]: values.includes(value) ? values.filter((item) => item !== value) : [...values, value] });
  };

  return (
    <aside className={mobile ? "h-full overflow-y-auto px-6 pb-8" : "sticky top-32 hidden w-56 shrink-0 self-start lg:block"}>
      {mobile && <div className="flex items-center justify-between border-b border-neutral-200 py-5"><h2 className="font-serif text-2xl">Filtros</h2><button onClick={onClose} aria-label="Cerrar filtros"><X /></button></div>}
      <div className="flex items-center justify-between border-b border-neutral-200 py-5">
        <span className="text-xs font-semibold uppercase tracking-[0.15em]">Filtrar por</span>
        <button onClick={() => onChange(initialFilters)} className="flex items-center gap-1 text-[10px] uppercase tracking-[0.1em] text-neutral-500 hover:text-black"><RotateCcw size={12} /> Limpiar</button>
      </div>
      <FilterGroup title="Categoría">
        {categories.map((category) => <CheckOption key={category} label={category} checked={filters.categories.includes(category)} onChange={() => toggle("categories", category)} />)}
      </FilterGroup>
      <FilterGroup title="Talla">
        <div className="flex flex-wrap gap-2">
          {sizes.map((size) => <button key={size} onClick={() => toggle("sizes", size)} className={`min-w-10 border px-3 py-2 text-xs transition ${filters.sizes.includes(size) ? "border-black bg-black text-white" : "border-neutral-300 hover:border-black"}`}>{size}</button>)}
        </div>
      </FilterGroup>
      <FilterGroup title="Color">
        {colors.map((color) => <CheckOption key={color} label={color} checked={filters.colors.includes(color)} onChange={() => toggle("colors", color)} />)}
      </FilterGroup>
      <FilterGroup title="Precio máximo">
        <input aria-label="Precio máximo" type="range" min="99" max="500" step="10" value={filters.maxPrice} onChange={(event) => onChange({ ...filters, maxPrice: Number(event.target.value) })} className="w-full accent-black" />
        <div className="mt-2 flex justify-between text-xs text-neutral-500"><span>S/ 99</span><span className="font-semibold text-black">S/ {filters.maxPrice}</span></div>
      </FilterGroup>
      <label className="flex cursor-pointer items-center gap-3 border-t border-neutral-200 py-5 text-sm">
        <input type="checkbox" checked={filters.offersOnly} onChange={(event) => onChange({ ...filters, offersOnly: event.target.checked })} className="size-4 accent-black" /> Solo ofertas
      </label>
      {mobile && <button onClick={onClose} className="mt-3 h-12 w-full bg-black text-xs font-semibold uppercase tracking-[0.15em] text-white">Ver resultados</button>}
    </aside>
  );
}

function FilterGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return <div className="border-b border-neutral-200 py-5"><h3 className="mb-4 text-xs font-semibold uppercase tracking-[0.12em]">{title}</h3><div className="space-y-3">{children}</div></div>;
}

function CheckOption({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) {
  return <label className="flex cursor-pointer items-center gap-3 text-sm text-neutral-700"><input type="checkbox" checked={checked} onChange={onChange} className="size-4 accent-black" />{label}</label>;
}
