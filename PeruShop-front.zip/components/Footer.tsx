import { Facebook, Instagram, Mail, MapPin, Phone } from "lucide-react";
import Link from "next/link";

export function Footer() {
  return (
    <footer className="mt-24 bg-[#171613] text-neutral-300">
      <div className="mx-auto grid max-w-[1440px] gap-12 px-5 py-16 sm:px-8 md:grid-cols-2 lg:grid-cols-4 lg:px-10">
        <div>
          <div className="text-xl font-semibold tracking-[0.3em] text-white">PERUSHOP</div>
          <p className="mt-5 max-w-xs text-sm leading-6 text-neutral-400">Moda contemporánea con una mirada local. Prendas cuidadas para vestir cada día con intención.</p>
          <div className="mt-6 flex gap-3">
            <a aria-label="Instagram" href="#" className="rounded-full border border-neutral-700 p-2.5 hover:border-white hover:text-white"><Instagram size={17} /></a>
            <a aria-label="Facebook" href="#" className="rounded-full border border-neutral-700 p-2.5 hover:border-white hover:text-white"><Facebook size={17} /></a>
          </div>
        </div>
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-white">Compra</h3>
          <div className="mt-5 flex flex-col gap-3 text-sm">
            <Link href="/productos">Todos los productos</Link><Link href="/productos?categoria=Mujer">Mujer</Link><Link href="/productos?categoria=Hombre">Hombre</Link><Link href="/productos?ofertas=true">Ofertas</Link>
          </div>
        </div>
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-white">Ayuda</h3>
          <div className="mt-5 flex flex-col gap-3 text-sm text-neutral-400"><span>Envíos y entregas</span><span>Cambios y devoluciones</span><span>Guía de tallas</span><span>Preguntas frecuentes</span></div>
        </div>
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-white">Contacto</h3>
          <div className="mt-5 space-y-4 text-sm text-neutral-400">
            <p className="flex gap-3"><MapPin size={18} className="shrink-0" />Av. Conquistadores 745, San Isidro</p>
            <p className="flex gap-3"><Phone size={18} />+51 1 555 0190</p>
            <p className="flex gap-3"><Mail size={18} />hola@perushop.pe</p>
          </div>
        </div>
      </div>
      <div className="border-t border-neutral-800 px-5 py-6 text-center text-xs text-neutral-500">© 2026 PeruShop. Experiencia de compra demostrativa.</div>
    </footer>
  );
}
