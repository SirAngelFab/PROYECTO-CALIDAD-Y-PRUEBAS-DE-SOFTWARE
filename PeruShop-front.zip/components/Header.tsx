"use client";

import { useStore } from "@/hooks/use-store";
import { Heart, Menu, Search, ShoppingBag, UserRound, X } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { Navbar } from "./Navbar";
import { SearchBar } from "./SearchBar";

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const { cartCount, favorites } = useStore();

  return (
    <>
      <div className="bg-neutral-950 px-4 py-2 text-center text-[10px] font-medium uppercase tracking-[0.18em] text-white sm:text-[11px]">
        Envío gratis en Lima por compras desde S/ 250
      </div>
      <header className="sticky top-0 z-50 border-b border-neutral-200/80 bg-white/95 backdrop-blur-md">
        <div className="mx-auto flex h-[74px] max-w-[1440px] items-center justify-between px-4 sm:px-6 lg:px-10">
          <div className="flex flex-1 items-center lg:hidden">
            <button onClick={() => setMenuOpen(true)} aria-label="Abrir menú" className="-ml-2 p-2"><Menu size={23} strokeWidth={1.5} /></button>
          </div>
          <div className="hidden flex-1 lg:block"><Navbar /></div>
          <Link href="/" aria-label="PeruShop, inicio" className="group flex flex-col items-center leading-none">
            <span className="text-[20px] font-semibold tracking-[0.32em] text-neutral-950 sm:text-[23px]">PERU</span>
            <span className="mt-1 text-[8px] font-medium tracking-[0.54em] text-[#8a6246]">SHOP</span>
          </Link>
          <div className="flex flex-1 items-center justify-end gap-0.5 sm:gap-2">
            <div className="mr-3 hidden xl:block"><SearchBar /></div>
            <button aria-label="Buscar" onClick={() => setSearchOpen((value) => !value)} className="p-2.5 xl:hidden"><Search size={20} strokeWidth={1.5} /></button>
            <Link aria-label="Iniciar sesión" href="/login" className="hidden p-2.5 sm:block"><UserRound size={20} strokeWidth={1.5} /></Link>
            <Link aria-label={`Favoritos: ${favorites.length}`} href="/favoritos" className="relative p-2.5">
              <Heart size={20} strokeWidth={1.5} />
              {favorites.length > 0 && <span className="absolute right-0.5 top-0.5 flex size-4 items-center justify-center rounded-full bg-[#8a6246] text-[9px] text-white">{favorites.length}</span>}
            </Link>
            <Link aria-label={`Carrito: ${cartCount} productos`} href="/carrito" className="relative p-2.5">
              <ShoppingBag size={20} strokeWidth={1.5} />
              {cartCount > 0 && <span className="absolute right-0.5 top-0.5 flex size-4 items-center justify-center rounded-full bg-neutral-950 text-[9px] text-white">{cartCount}</span>}
            </Link>
          </div>
        </div>
        <div className={`overflow-hidden border-t border-neutral-100 px-4 transition-all xl:hidden ${searchOpen ? "h-[60px] py-2 opacity-100" : "h-0 py-0 opacity-0"}`}>
          <SearchBar compact onClose={() => setSearchOpen(false)} />
        </div>
      </header>

      <div className={`fixed inset-0 z-[70] transition ${menuOpen ? "pointer-events-auto" : "pointer-events-none"}`}>
        <div onClick={() => setMenuOpen(false)} className={`absolute inset-0 bg-black/35 transition-opacity ${menuOpen ? "opacity-100" : "opacity-0"}`} />
        <aside className={`absolute left-0 top-0 flex h-full w-[88%] max-w-sm flex-col bg-white p-6 transition-transform duration-300 ${menuOpen ? "translate-x-0" : "-translate-x-full"}`}>
          <div className="flex items-center justify-between border-b border-neutral-200 pb-6">
            <span className="text-lg font-semibold tracking-[0.25em]">PERUSHOP</span>
            <button onClick={() => setMenuOpen(false)} aria-label="Cerrar menú" className="p-2"><X /></button>
          </div>
          <Navbar mobile onNavigate={() => setMenuOpen(false)} />
          <Link href="/login" onClick={() => setMenuOpen(false)} className="mt-auto flex items-center gap-3 border-t border-neutral-200 pt-6 text-sm"><UserRound size={19} /> Iniciar sesión</Link>
        </aside>
      </div>
    </>
  );
}
