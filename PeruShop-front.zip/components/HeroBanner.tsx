import { ArrowRight } from "lucide-react";
import Link from "next/link";

export function HeroBanner() {
  return (
    <section className="relative min-h-[620px] overflow-hidden bg-[#e9dfcf] sm:min-h-[690px] lg:min-h-[calc(100vh-106px)]">
      <div className="absolute inset-0 bg-[url('/images/hero-fashion.png')] bg-cover bg-[65%_center] sm:bg-center" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#efe6d8]/95 via-[#efe6d8]/45 to-transparent sm:from-transparent sm:via-transparent" />
      <div className="section-shell relative flex min-h-[620px] items-center sm:min-h-[690px] lg:min-h-[calc(100vh-106px)]">
        <div className="max-w-[590px] pb-14 pt-44 sm:pb-0 sm:pt-0">
          <p className="animate-fade-up text-[11px] font-semibold uppercase tracking-[0.28em] text-[#6e4f3a]">Nueva colección · Primavera 2026</p>
          <h1 className="animate-fade-up mt-5 font-serif text-[48px] leading-[0.96] tracking-[-0.04em] text-neutral-950 sm:text-7xl lg:text-[88px]">
            Elegancia que se siente <em className="font-normal">propia.</em>
          </h1>
          <p className="animate-fade-up-delay mt-6 max-w-md text-sm leading-6 text-neutral-700 sm:text-base sm:leading-7">Siluetas atemporales, texturas naturales y una nueva forma de vestir lo cotidiano.</p>
          <Link href="/productos" className="animate-fade-up-delay mt-8 inline-flex min-h-12 items-center gap-4 bg-neutral-950 px-7 py-3 text-xs font-semibold uppercase tracking-[0.15em] text-white transition hover:bg-[#79543b]">
            Comprar ahora <ArrowRight size={17} />
          </Link>
        </div>
      </div>
      <span className="absolute bottom-7 right-8 hidden -rotate-90 origin-right text-[10px] uppercase tracking-[0.25em] text-neutral-600 lg:block">Desliza para descubrir</span>
    </section>
  );
}
