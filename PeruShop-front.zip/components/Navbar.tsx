"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const links = [
  { href: "/", label: "Inicio" },
  { href: "/productos?categoria=Mujer", label: "Mujer" },
  { href: "/productos?categoria=Hombre", label: "Hombre" },
  { href: "/productos?categoria=Accesorios", label: "Accesorios" },
  { href: "/productos?ofertas=true", label: "Ofertas", accent: true },
];

export function Navbar({ mobile = false, onNavigate }: { mobile?: boolean; onNavigate?: () => void }) {
  const pathname = usePathname();
  return (
    <nav aria-label="Navegación principal" className={mobile ? "flex flex-col" : "hidden items-center gap-7 lg:flex"}>
      {links.map((link) => (
        <Link
          key={link.label}
          href={link.href}
          onClick={onNavigate}
          className={`${mobile ? "border-b border-neutral-200 py-5 text-xl" : "relative py-2 text-[12px] font-medium uppercase tracking-[0.14em] after:absolute after:bottom-0 after:left-0 after:h-px after:w-0 after:bg-black after:transition-all hover:after:w-full"} ${link.accent ? "text-[#9a3d2d]" : "text-neutral-800"} ${pathname === link.href ? "after:w-full" : ""}`}
        >
          {link.label}
        </Link>
      ))}
    </nav>
  );
}
