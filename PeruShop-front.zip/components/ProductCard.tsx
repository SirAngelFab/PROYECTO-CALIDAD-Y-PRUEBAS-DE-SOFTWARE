"use client";

import { formatPrice } from "@/data/products";
import { useStore } from "@/hooks/use-store";
import type { Product } from "@/types";
import { Heart, Plus } from "lucide-react";
import Link from "next/link";
import { ProductImage } from "./ProductImage";

export function ProductCard({ product }: { product: Product }) {
  const { addToCart, toggleFavorite, isFavorite } = useStore();
  const favorite = isFavorite(product.id);
  return (
    <article className="group min-w-0">
      <div className="relative aspect-[3/4] overflow-hidden bg-[#eee9e1]">
        <Link href={`/productos/${product.slug}`} aria-label={`Ver ${product.name}`}>
          <ProductImage product={product} className="absolute inset-0 transition-transform duration-700 group-hover:scale-[1.035]" />
        </Link>
        <div className="absolute left-3 top-3 flex flex-col items-start gap-1.5">
          {product.tags.map((tag) => <span key={tag} className={`${tag === "Oferta" ? "bg-[#9a3d2d] text-white" : "bg-white text-black"} px-2.5 py-1 text-[9px] font-semibold uppercase tracking-[0.12em] shadow-sm`}>{tag}</span>)}
        </div>
        <button
          onClick={() => toggleFavorite(product)}
          aria-label={favorite ? "Quitar de favoritos" : "Agregar a favoritos"}
          className="absolute right-3 top-3 flex size-9 items-center justify-center rounded-full bg-white/90 transition hover:bg-white"
        >
          <Heart size={17} fill={favorite ? "currentColor" : "none"} />
        </button>
        <button
          onClick={() => addToCart(product)}
          className="absolute inset-x-3 bottom-3 flex h-11 translate-y-2 items-center justify-center gap-2 bg-white/95 text-[10px] font-semibold uppercase tracking-[0.12em] opacity-0 shadow-sm transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100 focus:translate-y-0 focus:opacity-100 max-md:translate-y-0 max-md:opacity-100"
        >
          <Plus size={16} /> Agregar
        </button>
      </div>
      <div className="pt-4">
        <p className="text-[10px] uppercase tracking-[0.15em] text-neutral-500">{product.subcategory}</p>
        <Link href={`/productos/${product.slug}`} className="mt-1.5 block truncate text-sm font-medium hover:underline">{product.name}</Link>
        <div className="mt-2 flex items-center gap-2 text-sm">
          <span className={product.originalPrice ? "font-semibold text-[#9a3d2d]" : "font-medium"}>{formatPrice(product.price)}</span>
          {product.originalPrice && <span className="text-xs text-neutral-400 line-through">{formatPrice(product.originalPrice)}</span>}
        </div>
      </div>
    </article>
  );
}
