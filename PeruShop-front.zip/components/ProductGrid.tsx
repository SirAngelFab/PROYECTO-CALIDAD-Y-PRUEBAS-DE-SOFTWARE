import type { Product } from "@/types";
import { ProductCard } from "./ProductCard";

export function ProductGrid({ products, compact = false }: { products: Product[]; compact?: boolean }) {
  return (
    <div className={`grid grid-cols-2 gap-x-3 gap-y-9 sm:gap-x-5 ${compact ? "lg:grid-cols-4" : "md:grid-cols-3 xl:grid-cols-4"}`}>
      {products.map((product) => <ProductCard key={product.id} product={product} />)}
    </div>
  );
}
