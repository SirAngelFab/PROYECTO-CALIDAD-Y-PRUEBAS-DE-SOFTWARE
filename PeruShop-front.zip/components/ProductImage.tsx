import type { Product } from "@/types";

interface ProductImageProps {
  product: Pick<Product, "name" | "image" | "imagePosition">;
  className?: string;
  priority?: boolean;
}

export function ProductImage({ product, className = "" }: ProductImageProps) {
  return (
    <div
      role="img"
      aria-label={product.name}
      className={`bg-[#eee7dc] bg-no-repeat ${className}`}
      style={{
        backgroundImage: `url(${product.image})`,
        backgroundPosition: product.imagePosition,
        backgroundSize: "400% 500%",
      }}
    />
  );
}
