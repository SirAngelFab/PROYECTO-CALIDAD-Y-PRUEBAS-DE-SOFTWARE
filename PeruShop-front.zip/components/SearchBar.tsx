"use client";

import { Search, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

interface SearchBarProps {
  compact?: boolean;
  onClose?: () => void;
}

export function SearchBar({ compact = false, onClose }: SearchBarProps) {
  const router = useRouter();
  const [query, setQuery] = useState("");

  const submit = (event: FormEvent) => {
    event.preventDefault();
    const value = query.trim();
    router.push(value ? `/productos?q=${encodeURIComponent(value)}` : "/productos");
    onClose?.();
  };

  return (
    <form onSubmit={submit} role="search" className={`flex items-center border-b border-neutral-400 transition focus-within:border-black ${compact ? "w-full" : "w-48 xl:w-60"}`}>
      <Search size={16} strokeWidth={1.6} className="shrink-0" />
      <input
        aria-label="Buscar productos"
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Buscar"
        className="h-10 min-w-0 flex-1 bg-transparent px-3 text-sm outline-none placeholder:text-neutral-500"
      />
      {query && (
        <button type="button" aria-label="Limpiar búsqueda" onClick={() => setQuery("")} className="p-1 text-neutral-500 hover:text-black">
          <X size={15} />
        </button>
      )}
    </form>
  );
}
