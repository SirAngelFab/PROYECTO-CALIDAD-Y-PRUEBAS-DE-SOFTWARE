"use client";

import { ProductImage } from "@/components/ProductImage";
import { formatPrice } from "@/data/products";
import { useStore } from "@/hooks/use-store";
import type { CartLine, Product } from "@/types";
import { Minus, Plus, Trash2 } from "lucide-react";
import Link from "next/link";

export function CartItem({ line, product }: { line: CartLine; product: Product }) {
  const { updateQuantity, removeFromCart } = useStore();
  return (
    <article className="grid grid-cols-[100px_1fr] gap-4 border-b border-neutral-200 py-5 sm:grid-cols-[130px_1fr_auto] sm:gap-6 sm:py-7">
      <Link href={`/productos/${product.slug}`}><ProductImage product={product} className="aspect-[3/4]" /></Link>
      <div className="min-w-0 py-1">
        <p className="text-[10px] uppercase tracking-[.15em] text-neutral-500">{product.category}</p>
        <Link href={`/productos/${product.slug}`} className="mt-1 block text-sm font-medium sm:text-base">{product.name}</Link>
        <p className="mt-2 text-xs text-neutral-500">Talla: {line.size} · Color: {line.color}</p>
        <p className="mt-3 text-sm font-medium sm:hidden">{formatPrice(product.price * line.quantity)}</p>
        <div className="mt-4 flex items-center gap-4">
          <div className="flex h-9 items-center border border-neutral-300"><button aria-label="Reducir cantidad" onClick={() => updateQuantity(line.key, Math.max(1, line.quantity - 1))} className="px-2.5"><Minus size={13} /></button><span className="w-6 text-center text-xs">{line.quantity}</span><button aria-label="Aumentar cantidad" onClick={() => updateQuantity(line.key, Math.min(product.stock, line.quantity + 1))} className="px-2.5"><Plus size={13} /></button></div>
          <button onClick={() => removeFromCart(line.key)} className="flex items-center gap-1.5 text-[11px] text-neutral-500 underline hover:text-black"><Trash2 size={14} /> Eliminar</button>
        </div>
      </div>
      <p className="hidden py-1 text-sm font-medium sm:block">{formatPrice(product.price * line.quantity)}</p>
    </article>
  );
}
