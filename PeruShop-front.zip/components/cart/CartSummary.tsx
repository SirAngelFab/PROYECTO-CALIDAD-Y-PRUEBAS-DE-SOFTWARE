import { formatPrice } from "@/data/products";
import Link from "next/link";

export function CartSummary({ subtotal, checkout = false }: { subtotal: number; checkout?: boolean }) {
  const shipping = subtotal === 0 || subtotal >= 250 ? 0 : 15;
  return (
    <aside className="bg-[#f5f2ed] p-6 sm:p-8">
      <h2 className="font-serif text-2xl">Resumen del pedido</h2>
      <div className="mt-6 space-y-4 border-b border-neutral-300 pb-5 text-sm">
        <div className="flex justify-between"><span className="text-neutral-600">Subtotal</span><span>{formatPrice(subtotal)}</span></div>
        <div className="flex justify-between"><span className="text-neutral-600">Envío</span><span>{shipping ? formatPrice(shipping) : "Gratis"}</span></div>
      </div>
      <div className="flex justify-between py-5 text-base font-semibold"><span>Total</span><span>{formatPrice(subtotal + shipping)}</span></div>
      {!checkout && <Link href={subtotal ? "/checkout" : "/productos"} className="flex h-12 w-full items-center justify-center bg-black px-5 text-xs font-semibold uppercase tracking-[.15em] text-white transition hover:bg-[#79543b]">{subtotal ? "Continuar con la compra" : "Explorar productos"}</Link>}
      <p className="mt-4 text-center text-[11px] leading-5 text-neutral-500">Impuestos incluidos. El costo de envío se calcula según el total.</p>
    </aside>
  );
}
