"use client";

import { FilterSidebar, initialFilters, type Filters } from "@/components/FilterSidebar";
import { ProductGrid } from "@/components/ProductGrid";
import { products } from "@/data/products";
import { SlidersHorizontal, Search, X } from "lucide-react";
import { useMemo, useState } from "react";

interface ProductCatalogProps {
  initialQuery?: string;
  initialCategory?: string;
  initialOffers?: boolean;
  initialSort?: string;
}

export function ProductCatalog({ initialQuery = "", initialCategory, initialOffers = false, initialSort = "novedades" }: ProductCatalogProps) {
  const [filters, setFilters] = useState<Filters>({ ...initialFilters, categories: initialCategory ? [initialCategory] : [], offersOnly: initialOffers });
  const [query, setQuery] = useState(initialQuery);
  const [sort, setSort] = useState(initialSort);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const visibleProducts = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase("es");
    const filtered = products.filter((product) => {
      const matchesQuery = !normalized || `${product.name} ${product.category} ${product.subcategory}`.toLocaleLowerCase("es").includes(normalized);
      const matchesCategory = !filters.categories.length || filters.categories.includes(product.category);
      const matchesSize = !filters.sizes.length || filters.sizes.some((size) => product.sizes.includes(size));
      const matchesColor = !filters.colors.length || filters.colors.some((color) => product.colors.includes(color));
      const matchesPrice = product.price <= filters.maxPrice;
      const matchesOffer = !filters.offersOnly || product.tags.includes("Oferta");
      return matchesQuery && matchesCategory && matchesSize && matchesColor && matchesPrice && matchesOffer;
    });
    return [...filtered].sort((a, b) => {
      if (sort === "precio-asc") return a.price - b.price;
      if (sort === "precio-desc") return b.price - a.price;
      return Number(b.tags.includes("Nuevo")) - Number(a.tags.includes("Nuevo")) || Number(b.id) - Number(a.id);
    });
  }, [filters, query, sort]);

  return (
    <>
      <section className="bg-[#f2eee7] px-4 py-16 text-center sm:py-20">
        <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-[#79543b]">Colección completa</p>
        <h1 className="mt-3 font-serif text-5xl sm:text-6xl">Nuestra tienda</h1>
        <p className="mx-auto mt-4 max-w-xl text-sm leading-6 text-neutral-600">Prendas esenciales, nuevos favoritos y detalles que transforman tu forma de vestir.</p>
      </section>
      <div className="section-shell py-10 sm:py-14">
        <div className="mb-8 flex flex-col gap-4 border-b border-neutral-200 pb-6 sm:flex-row sm:items-end sm:justify-between">
          <label className="flex max-w-md flex-1 items-center border-b border-neutral-400 focus-within:border-black">
            <Search size={18} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar por nombre o categoría" className="h-11 w-full bg-transparent px-3 text-sm outline-none" />
            {query && <button onClick={() => setQuery("")} aria-label="Limpiar"><X size={16} /></button>}
          </label>
          <div className="flex items-center justify-between gap-3 sm:justify-end">
            <button onClick={() => setFiltersOpen(true)} className="flex h-11 items-center gap-2 border border-neutral-300 px-4 text-xs uppercase tracking-[0.12em] lg:hidden"><SlidersHorizontal size={16} /> Filtros</button>
            <label className="flex items-center gap-3 text-xs text-neutral-500"><span className="hidden sm:inline">Ordenar por</span><select value={sort} onChange={(event) => setSort(event.target.value)} className="h-11 border border-neutral-300 bg-white px-3 text-xs text-neutral-900 outline-none"><option value="novedades">Novedades</option><option value="precio-asc">Precio: menor a mayor</option><option value="precio-desc">Precio: mayor a menor</option></select></label>
          </div>
        </div>
        <div className="flex gap-9">
          <FilterSidebar filters={filters} onChange={setFilters} />
          <div className="min-w-0 flex-1">
            <p className="mb-5 text-xs text-neutral-500">{visibleProducts.length} {visibleProducts.length === 1 ? "producto" : "productos"}</p>
            {visibleProducts.length ? <ProductGrid products={visibleProducts} /> : <div className="flex min-h-80 flex-col items-center justify-center bg-neutral-50 px-6 text-center"><Search size={35} strokeWidth={1.2} /><h2 className="mt-5 font-serif text-3xl">No encontramos coincidencias</h2><p className="mt-2 text-sm text-neutral-500">Prueba con otra búsqueda o limpia los filtros.</p><button onClick={() => { setFilters(initialFilters); setQuery(""); }} className="mt-6 border-b border-black pb-1 text-xs font-semibold uppercase tracking-[0.12em]">Limpiar filtros</button></div>}
          </div>
        </div>
      </div>
      <div className={`fixed inset-0 z-[80] lg:hidden ${filtersOpen ? "pointer-events-auto" : "pointer-events-none"}`}>
        <div onClick={() => setFiltersOpen(false)} className={`absolute inset-0 bg-black/40 transition-opacity ${filtersOpen ? "opacity-100" : "opacity-0"}`} />
        <div className={`absolute right-0 top-0 h-full w-[88%] max-w-sm bg-white transition-transform duration-300 ${filtersOpen ? "translate-x-0" : "translate-x-full"}`}><FilterSidebar filters={filters} onChange={setFilters} mobile onClose={() => setFiltersOpen(false)} /></div>
      </div>
    </>
  );
}
