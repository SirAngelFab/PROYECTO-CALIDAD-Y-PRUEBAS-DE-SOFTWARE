"use client";

import { ProductGrid } from "@/components/ProductGrid";
import { ProductImage } from "@/components/ProductImage";
import { Button } from "@/components/ui/Button";
import { formatPrice, products } from "@/data/products";
import { useStore } from "@/hooks/use-store";
import type { Product } from "@/types";
import { ChevronLeft, Heart, Minus, Plus, Ruler, ShieldCheck, Truck } from "lucide-react";
import Link from "next/link";
import { useState } from "react";

export function ProductDetails({ product }: { product: Product }) {
  const [size, setSize] = useState(product.sizes[0]);
  const [color, setColor] = useState(product.colors[0]);
  const [quantity, setQuantity] = useState(1);
  const { addToCart, toggleFavorite, isFavorite } = useStore();
  const related = products.filter((item) => item.id !== product.id && item.category === product.category).slice(0, 4);

  return (
    <>
      <div className="section-shell py-5"><Link href="/productos" className="inline-flex items-center gap-1 text-xs text-neutral-500 hover:text-black"><ChevronLeft size={15} /> Volver a productos</Link></div>
      <section className="section-shell grid gap-8 lg:grid-cols-[minmax(0,1.35fr)_minmax(340px,.65fr)] lg:gap-14">
        <div className="grid grid-cols-2 gap-2 sm:gap-4">
          <ProductImage product={product} className="col-span-2 aspect-[4/5] sm:col-span-1 sm:aspect-[3/4]" />
          <ProductImage product={product} className="aspect-[3/4] brightness-[.96] sm:block" />
          <div className="relative aspect-[3/4] overflow-hidden bg-[#e9e2d8]"><ProductImage product={product} className="absolute inset-0 scale-125" /></div>
          <div className="relative aspect-[3/4] overflow-hidden bg-[#e9e2d8]"><ProductImage product={product} className="absolute inset-0 scale-110 saturate-[.8]" /></div>
        </div>

        <div className="lg:sticky lg:top-32 lg:self-start">
          <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-[#79543b]">{product.category} · {product.subcategory}</p>
          <h1 className="mt-3 font-serif text-4xl leading-tight sm:text-5xl">{product.name}</h1>
          <div className="mt-4 flex items-center gap-3"><span className="text-xl font-medium">{formatPrice(product.price)}</span>{product.originalPrice && <span className="text-sm text-neutral-400 line-through">{formatPrice(product.originalPrice)}</span>}{product.tags.includes("Oferta") && <span className="bg-[#9a3d2d] px-2 py-1 text-[9px] font-semibold uppercase tracking-wider text-white">Oferta</span>}</div>
          <p className="mt-6 text-sm leading-7 text-neutral-600">{product.description}</p>

          <div className="mt-8 border-t border-neutral-200 pt-6">
            <div className="flex items-center justify-between"><p className="text-xs font-semibold uppercase tracking-[0.14em]">Color: <span className="font-normal text-neutral-500">{color}</span></p></div>
            <div className="mt-3 flex flex-wrap gap-2">{product.colors.map((item) => <button key={item} onClick={() => setColor(item)} className={`border px-4 py-2.5 text-xs transition ${color === item ? "border-black bg-black text-white" : "border-neutral-300 hover:border-black"}`}>{item}</button>)}</div>
          </div>

          <div className="mt-6">
            <div className="flex items-center justify-between"><p className="text-xs font-semibold uppercase tracking-[0.14em]">Selecciona talla</p><button className="flex items-center gap-1 text-[11px] text-neutral-500 underline"><Ruler size={14} /> Guía de tallas</button></div>
            <div className="mt-3 flex flex-wrap gap-2">{product.sizes.map((item) => <button key={item} onClick={() => setSize(item)} className={`flex h-11 min-w-12 items-center justify-center border px-3 text-xs transition ${size === item ? "border-black bg-black text-white" : "border-neutral-300 hover:border-black"}`}>{item}</button>)}</div>
          </div>

          <div className="mt-7 flex gap-3">
            <div className="flex h-12 items-center border border-neutral-300"><button aria-label="Reducir cantidad" onClick={() => setQuantity((value) => Math.max(1, value - 1))} className="px-3"><Minus size={15} /></button><span className="w-8 text-center text-sm">{quantity}</span><button aria-label="Aumentar cantidad" onClick={() => setQuantity((value) => Math.min(product.stock, value + 1))} className="px-3"><Plus size={15} /></button></div>
            <Button className="h-12 flex-1" onClick={() => addToCart(product, size, color, quantity)}>Agregar al carrito</Button>
            <button onClick={() => toggleFavorite(product)} aria-label="Agregar a favoritos" className="flex size-12 shrink-0 items-center justify-center border border-neutral-300"><Heart size={19} fill={isFavorite(product.id) ? "currentColor" : "none"} /></button>
          </div>
          <p className="mt-3 text-xs text-neutral-500">{product.stock} unidades disponibles</p>
          <div className="mt-8 divide-y divide-neutral-200 border-y border-neutral-200 text-sm">
            <div className="flex items-center gap-3 py-4"><Truck size={19} strokeWidth={1.4} /><span>Envío estimado de 2 a 5 días hábiles</span></div>
            <div className="flex items-center gap-3 py-4"><ShieldCheck size={19} strokeWidth={1.4} /><span>Cambios disponibles durante 15 días</span></div>
          </div>
        </div>
      </section>

      <section className="section-shell py-24"><div className="mb-10"><p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-[#79543b]">También te puede gustar</p><h2 className="mt-3 font-serif text-4xl">Completa el look</h2></div><ProductGrid products={related} compact /></section>
    </>
  );
}
