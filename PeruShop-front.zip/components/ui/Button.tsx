import type { ButtonHTMLAttributes } from "react";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost";
  fullWidth?: boolean;
};

export function Button({
  variant = "primary",
  fullWidth = false,
  className = "",
  type = "button",
  ...props
}: ButtonProps) {
  const variants = {
    primary: "bg-neutral-950 text-white hover:bg-[#72543d] disabled:bg-neutral-300",
    secondary: "border border-neutral-950 bg-white text-neutral-950 hover:bg-neutral-950 hover:text-white",
    ghost: "bg-transparent text-neutral-700 hover:bg-neutral-100",
  };

  return (
    <button
      type={type}
      className={`inline-flex min-h-11 items-center justify-center gap-2 px-5 py-3 text-[12px] font-semibold uppercase tracking-[0.14em] transition-all duration-300 disabled:cursor-not-allowed ${variants[variant]} ${fullWidth ? "w-full" : ""} ${className}`}
      {...props}
    />
  );
}
