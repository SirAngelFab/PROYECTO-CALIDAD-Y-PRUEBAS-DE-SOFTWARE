import { forwardRef, type InputHTMLAttributes } from "react";

type InputProps = InputHTMLAttributes<HTMLInputElement> & {
  label?: string;
  error?: string;
};

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { label, error, className = "", id, ...props },
  ref,
) {
  const inputId = id ?? props.name;
  return (
    <label className="block" htmlFor={inputId}>
      {label && <span className="mb-2 block text-xs font-medium uppercase tracking-[0.12em] text-neutral-600">{label}</span>}
      <input
        ref={ref}
        id={inputId}
        className={`h-12 w-full border bg-white px-4 text-sm outline-none transition placeholder:text-neutral-400 focus:border-neutral-900 ${error ? "border-red-500" : "border-neutral-300"} ${className}`}
        {...props}
      />
      {error && <span className="mt-1.5 block text-xs text-red-600">{error}</span>}
    </label>
  );
});
