export function LoadingSkeleton({ cards = 4 }: { cards?: number }) {
  return (
    <div className="grid grid-cols-2 gap-x-3 gap-y-8 md:grid-cols-3 lg:grid-cols-4 lg:gap-x-5">
      {Array.from({ length: cards }).map((_, index) => (
        <div key={index} className="animate-pulse">
          <div className="aspect-[3/4] bg-neutral-100" />
          <div className="mt-4 h-3 w-2/3 bg-neutral-100" />
          <div className="mt-2 h-3 w-1/3 bg-neutral-100" />
        </div>
      ))}
    </div>
  );
}
