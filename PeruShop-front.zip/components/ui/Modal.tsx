"use client";

import { X } from "lucide-react";
import type { ReactNode } from "react";
import { useEffect } from "react";

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}

export function Modal({ open, onClose, title, children }: ModalProps) {
  useEffect(() => {
    if (!open) return;
    const close = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/45 p-4 backdrop-blur-sm" onMouseDown={onClose}>
      <section
        aria-modal="true"
        role="dialog"
        aria-labelledby="modal-title"
        className="relative w-full max-w-md bg-white p-7 shadow-2xl sm:p-9"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <button className="absolute right-4 top-4 p-2 text-neutral-500 hover:text-black" onClick={onClose} aria-label="Cerrar modal">
          <X size={20} />
        </button>
        <h2 id="modal-title" className="pr-8 font-serif text-3xl">{title}</h2>
        <div className="mt-5">{children}</div>
      </section>
    </div>
  );
}
