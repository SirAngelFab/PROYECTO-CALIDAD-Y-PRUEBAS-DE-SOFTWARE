"use client";

import { Check } from "lucide-react";

export function Toast({ message }: { message: string | null }) {
  return (
    <div
      aria-live="polite"
      className={`fixed bottom-5 left-1/2 z-[110] flex -translate-x-1/2 items-center gap-3 bg-neutral-950 px-5 py-3 text-sm text-white shadow-xl transition-all duration-300 ${message ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"}`}
    >
      <span className="flex size-5 items-center justify-center rounded-full bg-white text-black"><Check size={13} /></span>
      {message}
    </div>
  );
}
