import type { Product } from "@/types";

const image = "/images/catalog-sprite.png";
const positions = [
  "0% 0%", "33.333% 0%", "66.666% 0%", "100% 0%",
  "0% 25%", "33.333% 25%", "66.666% 25%", "100% 25%",
  "0% 50%", "33.333% 50%", "66.666% 50%", "100% 50%",
  "0% 75%", "33.333% 75%", "66.666% 75%", "100% 75%",
  "0% 100%", "33.333% 100%", "66.666% 100%", "100% 100%",
];

const base: Omit<Product, "image" | "imagePosition">[] = [
  { id: "1", slug: "vestido-lino-marfil", name: "Vestido Lino Marfil", description: "Vestido midi de caída ligera con escote limpio y acabado satinado. Una pieza versátil para ocasiones especiales o tardes de verano.", price: 229, category: "Mujer", subcategory: "Vestidos", sizes: ["XS", "S", "M", "L"], colors: ["Marfil", "Negro"], stock: 12, tags: ["Nuevo"] },
  { id: "2", slug: "blazer-sastrero-noche", name: "Blazer Sastrero Noche", description: "Blazer de estructura relajada, solapa clásica y confección precisa. Diseñado para elevar conjuntos casuales y formales.", price: 289, category: "Hombre", subcategory: "Blazers", sizes: ["S", "M", "L", "XL"], colors: ["Azul noche", "Negro"], stock: 9, tags: ["Exclusivo"] },
  { id: "3", slug: "chompa-alpaca-camel", name: "Chompa Alpaca Camel", description: "Tejido suave de alpaca peruana con cuello alto y silueta holgada. Abrigo natural con una textura excepcional.", price: 249, category: "Mujer", subcategory: "Tejidos", sizes: ["S", "M", "L"], colors: ["Camel", "Crema"], stock: 16, tags: ["Nuevo"] },
  { id: "4", slug: "sobrecamisa-olivo", name: "Sobrecamisa Olivo", description: "Sobrecamisa de algodón compacto con bolsillos utilitarios y corte recto contemporáneo.", price: 189, category: "Hombre", subcategory: "Camisas", sizes: ["S", "M", "L", "XL"], colors: ["Olivo", "Arena"], stock: 22, tags: [] },
  { id: "5", slug: "vestido-cruzado-borgona", name: "Vestido Cruzado Borgoña", description: "Vestido midi cruzado con cintura definida y mangas fluidas. Elegancia sencilla en un tono profundo.", price: 199, originalPrice: 259, category: "Mujer", subcategory: "Vestidos", sizes: ["XS", "S", "M", "L"], colors: ["Borgoña", "Negro"], stock: 8, tags: ["Oferta"] },
  { id: "6", slug: "tote-cuero-cacao", name: "Tote Cuero Cacao", description: "Bolso amplio de cuero granulado, doble asa y compartimento interior. Hecho para acompañar todos los días.", price: 279, category: "Accesorios", subcategory: "Bolsos", sizes: ["Única"], colors: ["Cacao", "Negro"], stock: 11, tags: ["Exclusivo"] },
  { id: "7", slug: "camisa-denim-clasica", name: "Camisa Denim Clásica", description: "Denim ligero lavado con corte regular, bolsillo de parche y botones mate.", price: 149, category: "Hombre", subcategory: "Camisas", sizes: ["S", "M", "L", "XL"], colors: ["Denim", "Índigo"], stock: 18, tags: [] },
  { id: "8", slug: "abrigo-lana-negro", name: "Abrigo Lana Negro", description: "Abrigo largo de lana con cinturón, solapas amplias y una silueta depurada.", price: 399, originalPrice: 489, category: "Mujer", subcategory: "Abrigos", sizes: ["S", "M", "L"], colors: ["Negro", "Camel"], stock: 6, tags: ["Oferta"] },
  { id: "9", slug: "zapatillas-costa-blancas", name: "Zapatillas Costa Blancas", description: "Zapatillas de cuero suave con suela color caramelo y líneas minimalistas.", price: 219, category: "Accesorios", subcategory: "Calzado", sizes: ["36", "37", "38", "39", "40", "41", "42"], colors: ["Blanco", "Arena"], stock: 25, tags: ["Nuevo"] },
  { id: "10", slug: "top-punto-negro", name: "Top Punto Negro", description: "Top de punto elástico con escote cuadrado y ajuste impecable para combinar en capas.", price: 99, category: "Mujer", subcategory: "Tops", sizes: ["XS", "S", "M", "L"], colors: ["Negro", "Crema"], stock: 30, tags: [] },
  { id: "11", slug: "chompa-trenzada-crudo", name: "Chompa Trenzada Crudo", description: "Jersey de algodón grueso con tejido trenzado, cuello redondo y calce relajado.", price: 189, category: "Hombre", subcategory: "Tejidos", sizes: ["S", "M", "L", "XL"], colors: ["Crudo", "Gris"], stock: 14, tags: ["Nuevo"] },
  { id: "12", slug: "vestido-satin-salvia", name: "Vestido Satén Salvia", description: "Vestido lencero midi de satén fluido con tirantes finos y corte al bies.", price: 179, originalPrice: 229, category: "Mujer", subcategory: "Vestidos", sizes: ["XS", "S", "M", "L"], colors: ["Salvia", "Champán"], stock: 10, tags: ["Oferta"] },
  { id: "13", slug: "casaca-gamuza-cafe", name: "Casaca Gamuza Café", description: "Casaca de tacto gamuza con cuello camisero y herrajes oscuros. Una capa atemporal.", price: 329, category: "Hombre", subcategory: "Casacas", sizes: ["S", "M", "L", "XL"], colors: ["Café", "Negro"], stock: 7, tags: ["Exclusivo"] },
  { id: "14", slug: "camisa-popelina-blanca", name: "Camisa Popelina Blanca", description: "Camisa de algodón fresco con hombro relajado y bajo curvo. Esencial, limpia y precisa.", price: 129, category: "Mujer", subcategory: "Camisas", sizes: ["XS", "S", "M", "L"], colors: ["Blanco", "Celeste"], stock: 24, tags: [] },
  { id: "15", slug: "botas-altas-cacao", name: "Botas Altas Cacao", description: "Bota alta de acabado liso, punta almendrada y tacón estable de altura media.", price: 359, category: "Accesorios", subcategory: "Calzado", sizes: ["36", "37", "38", "39", "40"], colors: ["Cacao", "Negro"], stock: 8, tags: ["Nuevo"] },
  { id: "16", slug: "sweater-merino-borgona", name: "Sweater Merino Borgoña", description: "Sweater de lana merino fina con cuello redondo y terminaciones acanaladas.", price: 199, category: "Hombre", subcategory: "Tejidos", sizes: ["S", "M", "L", "XL"], colors: ["Borgoña", "Carbón"], stock: 17, tags: [] },
  { id: "17", slug: "traje-relajado-arena", name: "Traje Relajado Arena", description: "Conjunto de blazer y pantalón amplio con mezcla de lino, pensado para vestir con naturalidad.", price: 459, category: "Mujer", subcategory: "Conjuntos", sizes: ["S", "M", "L"], colors: ["Arena", "Tabaco"], stock: 5, tags: ["Exclusivo", "Nuevo"] },
  { id: "18", slug: "polo-pima-negro", name: "Polo Pima Negro", description: "Polo premium de algodón pima peruano, tacto sedoso y cuello estructurado.", price: 119, category: "Hombre", subcategory: "Polos", sizes: ["S", "M", "L", "XL"], colors: ["Negro", "Blanco", "Olivo"], stock: 35, tags: [] },
  { id: "19", slug: "falda-plisada-cacao", name: "Falda Plisada Cacao", description: "Falda midi de plisado fino con movimiento ligero y cintura elástica oculta.", price: 159, originalPrice: 199, category: "Mujer", subcategory: "Faldas", sizes: ["XS", "S", "M", "L"], colors: ["Cacao", "Negro"], stock: 13, tags: ["Oferta"] },
  { id: "20", slug: "cartera-estructurada-negra", name: "Cartera Estructurada Negra", description: "Cartera de líneas arquitectónicas, asa superior y cierre metálico discreto.", price: 249, category: "Accesorios", subcategory: "Bolsos", sizes: ["Única"], colors: ["Negro", "Borgoña"], stock: 10, tags: ["Nuevo"] },
];

export const products: Product[] = base.map((product, index) => ({
  ...product,
  image,
  imagePosition: positions[index],
}));

export const getProductById = (id: string) => products.find((product) => product.id === id);
export const getProductBySlug = (slug: string) => products.find((product) => product.slug === slug);

export const formatPrice = (price: number) =>
  new Intl.NumberFormat("es-PE", { style: "currency", currency: "PEN", minimumFractionDigits: 0 }).format(price);
