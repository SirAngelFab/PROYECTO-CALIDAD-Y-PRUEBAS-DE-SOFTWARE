"use client";

import { Toast } from "@/components/ui/Toast";
import type { CartLine, Product } from "@/types";
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

interface StoreContextValue {
  cart: CartLine[];
  favorites: string[];
  cartCount: number;
  addToCart: (product: Product, size?: string, color?: string, quantity?: number) => void;
  removeFromCart: (key: string) => void;
  updateQuantity: (key: string, quantity: number) => void;
  toggleFavorite: (product: Product) => void;
  isFavorite: (productId: string) => boolean;
  clearCart: () => void;
  notify: (message: string) => void;
}

const StoreContext = createContext<StoreContextValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartLine[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      try {
        setCart(JSON.parse(localStorage.getItem("perushop-cart") ?? "[]"));
        setFavorites(JSON.parse(localStorage.getItem("perushop-favorites") ?? "[]"));
      } catch {
        localStorage.removeItem("perushop-cart");
        localStorage.removeItem("perushop-favorites");
      } finally {
        setHydrated(true);
      }
    });
    return () => window.cancelAnimationFrame(frame);
  }, []);

  useEffect(() => {
    if (hydrated) localStorage.setItem("perushop-cart", JSON.stringify(cart));
  }, [cart, hydrated]);

  useEffect(() => {
    if (hydrated) localStorage.setItem("perushop-favorites", JSON.stringify(favorites));
  }, [favorites, hydrated]);

  const notify = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(null), 2600);
  }, []);

  const addToCart = useCallback((product: Product, size?: string, color?: string, quantity = 1) => {
    const selectedSize = size ?? product.sizes[0];
    const selectedColor = color ?? product.colors[0];
    const key = `${product.id}-${selectedSize}-${selectedColor}`;
    setCart((current) => {
      const line = current.find((item) => item.key === key);
      if (line) return current.map((item) => item.key === key ? { ...item, quantity: Math.min(item.quantity + quantity, product.stock) } : item);
      return [...current, { key, productId: product.id, size: selectedSize, color: selectedColor, quantity }];
    });
    notify(`${product.name} se agregó al carrito`);
  }, [notify]);

  const removeFromCart = useCallback((key: string) => {
    setCart((current) => current.filter((item) => item.key !== key));
    notify("Producto eliminado del carrito");
  }, [notify]);

  const updateQuantity = useCallback((key: string, quantity: number) => {
    if (quantity < 1) return;
    setCart((current) => current.map((item) => item.key === key ? { ...item, quantity } : item));
  }, []);

  const toggleFavorite = useCallback((product: Product) => {
    setFavorites((current) => {
      const exists = current.includes(product.id);
      notify(exists ? "Eliminado de favoritos" : "Guardado en favoritos");
      return exists ? current.filter((id) => id !== product.id) : [...current, product.id];
    });
  }, [notify]);

  const value = useMemo(() => ({
    cart,
    favorites,
    cartCount: cart.reduce((total, item) => total + item.quantity, 0),
    addToCart,
    removeFromCart,
    updateQuantity,
    toggleFavorite,
    isFavorite: (productId: string) => favorites.includes(productId),
    clearCart: () => setCart([]),
    notify,
  }), [cart, favorites, addToCart, removeFromCart, updateQuantity, toggleFavorite, notify]);

  return <StoreContext.Provider value={value}>{children}<Toast message={toast} /></StoreContext.Provider>;
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error("useStore debe utilizarse dentro de StoreProvider");
  return context;
}
