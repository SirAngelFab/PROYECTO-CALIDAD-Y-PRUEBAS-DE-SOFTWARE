export type Category = "Mujer" | "Hombre" | "Accesorios";

export interface Product {
  id: string;
  slug: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: Category;
  subcategory: string;
  sizes: string[];
  colors: string[];
  stock: number;
  tags: ("Nuevo" | "Oferta" | "Exclusivo")[];
  image: string;
  imagePosition: string;
}

export interface CartLine {
  key: string;
  productId: string;
  size: string;
  color: string;
  quantity: number;
}
